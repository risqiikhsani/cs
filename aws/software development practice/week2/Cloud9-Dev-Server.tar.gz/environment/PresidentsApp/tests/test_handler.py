from app import presidents

def test_presidents_list_all(mocker):

    mocker.patch.object(presidents, 'DYNAMO')

    # mock the response from dynamodb
    TEST_DATA = {'Items': [
        {   'ID': {'N': '99'},
            'Name': {'S': 'President X'},
            'Born': {'S': "1735-10-30"}, 
            'Died': {'S': "1826-07-04"}
        }]
    }
    presidents.DYNAMO.scan.return_value = TEST_DATA

    with presidents.app.app_context():
        result = presidents.list_all()
        assert "President X" in result
        assert "aged 91" in result

