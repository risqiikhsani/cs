import os
import boto3
import yaml

dynamo = boto3.client('dynamodb')

__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
with open(os.path.join(__location__, "database.yml")) as file:
    database = yaml.load(file, Loader=yaml.FullLoader)

for president in database:
    print(f"Putting {president['Name']}")
    dynamo.put_item(
        TableName='Presidents',
        Item={
            'ID': { 'N': str(president["ID"]) },
            'Name': { 'S': president["Name"] },
            'Born': { 'S': president["Born"] },
            'Died': { 'S': president["Died"] }
        })