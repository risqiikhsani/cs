import dateutil
from dateutil.relativedelta import relativedelta

from flask import Flask, render_template
import boto3

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True
DYNAMO = boto3.client('dynamodb')


@app.route("/")
def list_all():
    results = DYNAMO.scan(
        TableName='Presidents',
    )
    print(results)

    presidents = []
    for p in sorted(results["Items"], key=lambda x: int(x["ID"]["N"])):
        president = {
            "Name": p["Name"]["S"],
            "Born": dateutil.parser.parse(p["Born"]["S"]),
            "Died": dateutil.parser.parse(p["Died"]["S"]),
        }
        # relativedelta solution
        president["Aged"] = relativedelta(
            president["Died"], president["Born"]).years
        presidents.append(president)

    return render_template('main.html', presidents=presidents)
