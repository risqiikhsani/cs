#!/bin/bash
pytest tests/ --cov-report=html --cov=app